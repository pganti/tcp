char tbit_version[] = "0.6.3";
