/*
 * Copyright (C) 2007 WIDE Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the project nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE PROJECT AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
/*
 $Id: binread.c,v 1.14 2007/12/05 05:31:41 nishida Exp $
 */
#include "tcpillust.h"
#include <sys/socket.h>
#include <pcap.h>
#include <net/if_arp.h>
#if defined (linux) || defined(__APPLE__)
#define __FAVOR_BSD
#else
#include <net/slip.h>
#endif
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <net/if.h>
#include <netinet/if_ether.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>

#define PPP_HDRLEN 4
#define NULL_HDRLEN 4
#define ATM_HDRLEN 8
#ifndef SLIP_HDRLEN
#define SLIP_HDRLEN 16
#endif

static void dumper __P((u_char *, const struct pcap_pkthdr *, const u_char *));
static void dumpip __P((u_char *, const struct timeval *, int));
static void dumpip6 __P((u_char *, const struct timeval *, int));
static int pcap_dlt;
static int pcap_snap;
static long seq1;
static long seq2;
static long base;
static long mbase;
static u_char *pktbuffer;
static struct tcppkt *tpacket;

struct tcppkt *
read_binfile(filename)
	char	*filename;
{
	char errbuf[PCAP_ERRBUF_SIZE];
	pcap_t *pc;
	int	count = -1;

	if (!(pc = pcap_open_offline(filename, errbuf))){
		perror("pcap_open");
		exit(-1);
	}
	pcap_dlt = pcap_datalink(pc);
	pcap_snap = pcap_snapshot(pc);

	if (!pktcount) {
		if ((pktbuffer = (u_char *)malloc(pcap_snap +4)) == NULL){
			perror("malloc");
			exit(-1);
		}
	}

	if (pcap_loop(pc, count, dumper, (u_char *)NULL) < 0) {
		perror("pcap_loop");
		exit(-2);
	}
	pcap_close(pc);
	capendtime = tpacket[pktcount -1].captime - tpacket[0].captime; 

	return tpacket;
}

static void
dumper(u_char *user, const struct pcap_pkthdr *inh, const u_char *inp)
{
	u_char *p;
	int caplen = inh->caplen;

	if (caplen > pcap_snap) { 
		fprintf(stderr, "packet too large %s:%d\n", __FILE__, __LINE__);
		exit(-1);
	}

	memcpy(pktbuffer, inp, caplen);
	p = pktbuffer;

	switch (pcap_dlt) {
		case DLT_EN10MB:
			if (caplen < (sizeof (struct ether_header))) 
				return;
			p += sizeof(struct ether_header);
			dumpip(p, &inh->ts, caplen);
		break;

		case DLT_SLIP:
			if (caplen < SLIP_HDRLEN)
				return;
			p += SLIP_HDRLEN;
			dumpip(p, &inh->ts, caplen);
		break;

		case DLT_PPP:
			if (caplen < PPP_HDRLEN) 
				return;
			p += PPP_HDRLEN;
			dumpip(p, &inh->ts, caplen);
		break;

		case DLT_NULL:
			if (caplen < NULL_HDRLEN) 
				return;
			p += NULL_HDRLEN;
			dumpip(p, &inh->ts, caplen);
		break;

		case DLT_ATM_RFC1483:
			if (caplen < ATM_HDRLEN) 
				return;
			p += ATM_HDRLEN;
			dumpip(p, &inh->ts, caplen);
		break;

		default:
			fprintf(stderr, "Unknown DLT %x\n", pcap_dlt);
			exit(-1);
		break;
	}
}

static void
dumpip(u_char *p, const struct timeval *tvp, int caplen)
{
	struct ip *ip;
	struct tcphdr *tcp; 
	int len;
	long datalen;
	static u_long addr1, addr2;
	static u_short port1, port2;

	ip = (struct ip *)p;
	if (ip->ip_v == 6){
		/* this is IPv6 */
		dumpip6(p, tvp, caplen);
		return;
	}
	if (ip->ip_p != IPPROTO_TCP){
		printf("not tcp\n");
		return;
	}

	/* skip ip header */
	p+= ip->ip_hl * 4;	
	tcp = (struct tcphdr *)p;
	len = (tcp->th_off) *4 - sizeof(struct tcphdr);

	if (pktcount) {
		if ((ntohl(ip->ip_src.s_addr) != addr1 || 
				ntohl(ip->ip_dst.s_addr) != addr2) && 
			(ntohl(ip->ip_src.s_addr) != addr2 || 
					ntohl(ip->ip_dst.s_addr) != addr1)){
			printf("Warning: address unmatch\n");
			return;
		}

		if ((ntohs(tcp->th_sport) != port1  ||
		     ntohs(tcp->th_dport) != port2) && 
			(ntohs(tcp->th_sport) != port2  ||
		     ntohs(tcp->th_dport) != port1)){
			printf("Warning: port unmatch\n");
			return;
		}
	} 

	if (!pktcount){
		isv6 = 0; /* this is ipv4 connection */
		tpacket = (struct tcppkt *)malloc(sizeof(struct tcppkt));
		if (tpacket == NULL){
			perror("malloc");
			exit(-1);	
		}
		pktcount += 1;
	} else {
		pktcount += 1;
		tpacket = (struct tcppkt *)realloc(tpacket, 
								sizeof(struct tcppkt) * pktcount);
		if (tpacket == NULL){
			perror("realloc");
			exit(-1);	
		}
	}

	if (pktcount == 1){
		addr1 = ntohl(ip->ip_src.s_addr);
		addr2 = ntohl(ip->ip_dst.s_addr);
		port1 = ntohs(tcp->th_sport);
		port2 = ntohs(tcp->th_dport);
		seq1 = ntohl(tcp->th_seq);
		seq2 = ntohl(tcp->th_ack);
		base = tvp->tv_sec;
		mbase = tvp->tv_usec;
	} else {
		if (!seq2) {
			if (addr1 == ntohl(ip->ip_src.s_addr)) seq2 = ntohl(tcp->th_ack);
			else seq2 = ntohl(tcp->th_seq);
		}
	}

	datalen = ntohs(ip->ip_len) - ip->ip_hl * 4 - tcp->th_off *4;

	memset(&tpacket[pktcount -1], 0, sizeof(struct tcppkt));
	tpacket[pktcount -1].captime = 
			(tvp->tv_sec - base) + (float)(tvp->tv_usec - mbase)/1000000.0;
	tpacket[pktcount -1].src6_addr[3] = ntohl(ip->ip_src.s_addr);
	tpacket[pktcount -1].dst6_addr[3] = ntohl(ip->ip_dst.s_addr);
	tpacket[pktcount -1].id = ntohs(ip->ip_id);

	if (addr1 == ntohl(ip->ip_src.s_addr)) {
		tpacket[pktcount -1].seq = ntohl(tcp->th_seq) - seq1;
		if (ntohl(tcp->th_ack))
			tpacket[pktcount -1].ack = ntohl(tcp->th_ack) - seq2;
	} else {
		tpacket[pktcount -1].seq = ntohl(tcp->th_seq) - seq2;
		if (ntohl(tcp->th_ack))
			tpacket[pktcount -1].ack = ntohl(tcp->th_ack) - seq1;
	}

	tpacket[pktcount -1].src_port = ntohs(tcp->th_sport);
	tpacket[pktcount -1].dst_port = ntohs(tcp->th_dport);
	tpacket[pktcount -1].win = ntohs(tcp->th_win);
	tpacket[pktcount -1].flags = tcp->th_flags;
	tpacket[pktcount -1].datalen = datalen;

	if (!snaplen) snaplen = caplen;

	if ((tpacket[pktcount -1].data = malloc(snaplen)) == NULL){
		fprintf(stderr, "cannot malloc for packet data. \
						Please choose small snaplen value\n");
		exit(-1);
	}
	memcpy(tpacket[pktcount -1].data, ip, snaplen);

#if 0
	/* process tcp option, currently not implemented */ 
	p += sizeof(struct tcphdr);
	while(len > 0){
		if (*p == 0 || *p == 1){
			len --;
			p ++;
			continue;
		}
		if (*p == TCPOPT_TIMESTAMP){
			len -= 10;
			p+= 10;
			continue;
		}
		p ++;
		optlen = *p -1;
		p += optlen;
		len -= optlen; 
	}
#endif
}

static void
dumpip6(u_char *p, const struct timeval *tvp, int caplen)
{
	struct ip6_hdr *ip6;
	struct tcphdr *tcp; 
	static u_long addr1[4], addr2[4];
	static u_short port1, port2;
	long datalen;
	u_char proto;
	int len;

	ip6 = (struct ip6_hdr *)p;
	/* skip ip header */
	p += sizeof(struct ip6_hdr);
	if (ip6->ip6_nxt != IPPROTO_TCP){
		/* skip external header */
		while(1){
			proto = ((struct ip6_hbh *)p)->ip6h_nxt;
			len = ((struct ip6_hbh *)p)->ip6h_len;
			if (proto == IPPROTO_HOPOPTS || proto == IPPROTO_ROUTING 
				|| proto == IPPROTO_DSTOPTS){
					p += len;
			}
			break;
		}
		if (proto != IPPROTO_TCP){
			printf("Not tcp\n");
			return;
		}
		p += len;
	}
	tcp = (struct tcphdr *)p;
    len = (tcp->th_off) *4 - sizeof(struct tcphdr);

	if (pktcount){ 
		if ((memcmp(ip6->ip6_src.s6_addr, addr1, 16) || 
		     memcmp(ip6->ip6_dst.s6_addr, addr2, 16)) && 
		    (memcmp(ip6->ip6_src.s6_addr, addr2, 16) || 
		     memcmp(ip6->ip6_dst.s6_addr, addr1, 16))){ 
			printf("Warning: address unmatch\n");
			return;
		}
		if ((ntohs(tcp->th_sport) != port1  ||
			ntohs(tcp->th_dport) != port2) &&
			(ntohs(tcp->th_sport) != port2  ||
			ntohs(tcp->th_dport) != port1)){
			printf("Warning: port unmatch\n");
			return;
		}
	}

	if (!pktcount){
		tpacket = (struct tcppkt *)malloc(sizeof(struct tcppkt));
		if (tpacket == NULL){
			perror("malloc");
			exit(-1);	
		}
		pktcount += 1;
		isv6 = 1; /* this is ipv6 connection */
	} else {
		pktcount += 1;
		tpacket = (struct tcppkt *)realloc(tpacket, 
								sizeof(struct tcppkt) * pktcount);
		if (tpacket == NULL){
			perror("realloc");
			exit(-1);	
		}
	}

	if (pktcount == 1){
		memcpy(&addr1, ip6->ip6_src.s6_addr, 16);
		memcpy(&addr2, ip6->ip6_dst.s6_addr, 16);
		port1 = ntohs(tcp->th_sport);
		port2 = ntohs(tcp->th_dport);
		seq1 = ntohl(tcp->th_seq);
		seq2 = ntohl(tcp->th_ack);
		base = tvp->tv_sec;
		mbase = tvp->tv_usec;
	} else {
		if (!seq2) {
			if (!memcmp(ip6->ip6_src.s6_addr, addr1, 16))
				seq2 = ntohl(tcp->th_ack);
			else 
				seq2 = ntohl(tcp->th_seq);
		}
	}

	datalen = ntohs(ip6->ip6_plen) - tcp->th_off *4;

	memset(&tpacket[pktcount -1], 0, sizeof(struct tcppkt));
	tpacket[pktcount -1].captime = 
			(tvp->tv_sec - base) + (float)(tvp->tv_usec - mbase)/1000000.0;
	memcpy(tpacket[pktcount -1].src6_addr, ip6->ip6_src.s6_addr, 16);
	memcpy(tpacket[pktcount -1].dst6_addr, ip6->ip6_dst.s6_addr, 16);
	tpacket[pktcount -1].flow = ip6->ip6_flow;

	if (!memcmp(addr1, ip6->ip6_src.s6_addr, 16)) {
		tpacket[pktcount -1].seq = ntohl(tcp->th_seq) - seq1;
		if (ntohl(tcp->th_ack))
			tpacket[pktcount -1].ack = ntohl(tcp->th_ack) - seq2;
	} else {		
		tpacket[pktcount -1].seq = ntohl(tcp->th_seq) - seq2;
		if (ntohl(tcp->th_ack))
			tpacket[pktcount -1].ack = ntohl(tcp->th_ack) - seq1;
	}

	tpacket[pktcount -1].src_port = ntohs(tcp->th_sport);
	tpacket[pktcount -1].dst_port = ntohs(tcp->th_dport);
	tpacket[pktcount -1].win = ntohs(tcp->th_win);
	tpacket[pktcount -1].flags = tcp->th_flags;
	tpacket[pktcount -1].datalen = datalen;

	if (!snaplen) snaplen = caplen;

	if ((tpacket[pktcount -1].data = malloc(snaplen)) == NULL){
		fprintf(stderr, "cannot malloc for packet data. \
				Please choose small snaplen value\n");
		exit(-1);
	}
	memcpy(tpacket[pktcount -1].data, ip6, snaplen);

	if (!snaplen) snaplen = caplen;

	if ((tpacket[pktcount -1].data = malloc(snaplen)) == NULL){
		fprintf(stderr, "cannot malloc for packet data. \
						Please choose small snaplen value\n");
		exit(-1);
	}
	memcpy(tpacket[pktcount -1].data, ip6, snaplen);
}

char *
create_msg(int id, int fast)
{
	static char buf[65535];
	u_char *p = (u_char *)ilt[id].data;
	struct ip *ip = (struct ip *)p;
	struct ip6_hdr *ip6;
    struct tcphdr *tcp;
	int i, datalen, off, hlen = 0;
	u_char proto;
	void tcp_print();

	if (!isv6) {
		datalen = ntohs(ip->ip_len) - ip->ip_hl * 4;
		p+= ip->ip_hl * 4;
		tcp = (struct tcphdr *)p;
		off = sizeof(struct ip);
	} else {
		ip6 = (struct ip6_hdr *)p;
		/* skip ip header */
		p += sizeof(struct ip6_hdr);
		if (ip6->ip6_nxt != IPPROTO_TCP){
           /* skip external header */
			while(1){
				proto = ((struct ip6_hbh *)p)->ip6h_nxt;
				hlen = ((struct ip6_hbh *)p)->ip6h_len;
				if (proto == IPPROTO_HOPOPTS 
						|| proto == IPPROTO_ROUTING || proto == IPPROTO_DSTOPTS){
					p += hlen;
				}
				break;
			}
			p += hlen;
		}
		tcp = (struct tcphdr *)p;
    	datalen = ntohs(ip6->ip6_plen);
		off = sizeof(struct ip6_hdr) + hlen;
	}
	bzero(buf, sizeof(buf));

	if (datalen + off < snaplen) 
		tcp_print(p, datalen, ip, 0, buf);
	else
		tcp_print(p, datalen, ip, 1, buf);

	if (fast) return buf;	

	/* hex dump */
	sprintf(buf + strlen(buf), "\n");
	off = 0;
	p = (u_char *)ilt[id].data;
	hlen = ip->ip_hl * 4 + tcp->th_off * 4;
	while(hlen) {
		sprintf(buf + strlen(buf), "\n      0x%04x:  ", off);
		if (hlen >= 16) {
			for (i = 0; i < 16; i ++) {
				if (i % 2)
					sprintf(buf + strlen(buf), "%02x ", *(p +i));
				else
					sprintf(buf + strlen(buf), "%02x", *(p +i));
			}
		} else {
			for (i = 0; i < hlen; i ++) {
				if (i % 2)
					sprintf(buf + strlen(buf), "%02x ", *(p +i));
				else
					sprintf(buf + strlen(buf), "%02x", *(p +i));
			}
			break;
		}
		hlen -= 16;
		p += 16;
		off += 16;
	}

	return buf;
}
