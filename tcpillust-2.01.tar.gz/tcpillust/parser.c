/*
 * Copyright (C) 2007 WIDE Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the project nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE PROJECT AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
/*
 $Id: parser.c,v 1.13 2008/02/10 10:41:46 nishida Exp $
 */

#include <stdio.h>
#include <sys/param.h>
#include <sys/time.h>
#ifdef linux
#define __FAVOR_BSD
#endif
#include <netinet/tcp.h>
#include "tcpillust.h"

static float timegap;
static int ilt_flag = 0;

#define UNSETVAL 99999
#define MAXSAMPLE 10000
static int iltsearch __P((int, float));
static float calculate_delay __P((int, int));
static float calculate_delay2 __P((int, int, int, int));

static struct tcppkt * read_file __P((char *));
static void create_iltdata __P((void));
static void create_iltdata2 __P((void));
static int filetype = 0;  /* default file type is binary */
static int filecount = 0;

void
parser(argc, argv)
	int		argc;
	char	**argv;
{
	int	opt;
	int xloc, yloc;
	u_int width, height;
	extern char *optarg;
	extern int optind;
	void Usage();

	timegap = delay = UNSETVAL;
	snaplen = 0;

	if (argc == 1) return;
	while ((opt = getopt(argc, argv, "vVd:s:g:h")) != -1) { 
		switch(opt){
		case 'V':
			ilt_flag |= FL_VERBOSE;	
			break;

		case 'd':
			delay = atof(optarg);
			break;

		case 's':
			dsnaplen = snaplen = atoi(optarg);
			break;

		case 'g':
			XParseGeometry(optarg, &xloc, &yloc, &width, &height);
			appl_x = xloc;
			appl_y = yloc;
			appl_width = width;
			appl_height = height;
			break;

		case 'v':
			fprintf(stderr, "%s version %s\n", PROG_NAME, PROG_VERSION);
			exit(0);
			break;

		case 'h':
		default:
			Usage();
			break;
		}
	}

	argc -= optind;
	argv += optind;

    if (argc != 1 && argc != 2) Usage();

	load_file(argc, argv, 0);
}

void
load_file(argc, argv, clear)
	int argc;
	char **argv;
	int clear;
{
	int i;

	if (clear){
		/* clear flag is set, so clear all record */
		for (i = 0; i < pktcount; i ++){
			if (packet[i].data) free(packet[i].data);
		}
		if (pktcount) {
			free(ilt);
			free(packet);
		}
		for (i = 0; i < pktcount2; i ++){
			if (packet2[i].data) free(packet2[i].data);
		}
		if (pktcount2) free(packet2);
		pktcount = 0;
		pktcount2 = 0;
		snaplen = dsnaplen;
	}

	filecount = argc;

	/* read logfile */
	if (filecount == 1){
		packet = read_file(argv[0]);
		create_iltdata();
	} else {
		packet2 = read_file(argv[1]);
		pktcount2 = pktcount;
		pktcount = 0;
		packet = read_file(argv[0]);
		create_iltdata2();
	}

	loaded = 1;
}

struct tcppkt *
read_file(filename)
	char	*filename;
{
	struct tcppkt *ret;
	if (ilt_flag & FL_VERBOSE) 
			fprintf(stderr, " reading from %s...", filename);
	if (!filetype) ret = read_binfile(filename);
	if (ilt_flag & FL_VERBOSE) fprintf(stderr, " done.\n");

	return ret;
}

/*
 * create iltdata from sampled packets in two files
 */
void
create_iltdata2()
{
	struct tcppkt *tmpp;
	int tmp, i, id1 = -1, id2 = -1;
	float d, diff;

	if (pktcount2 > pktcount) {
		/* data in *packet2 seems to be more reliable than data in *packet.
		 * so, swap them
		 */
		tmpp = packet;
		packet = packet2;
		packet2 = tmpp;

		tmp = pktcount;
		pktcount = pktcount2;
		pktcount2 = tmp;
	}

	create_iltdata();
	for (i = 0; i < pktcount; i ++){
		d = calculate_delay(i, 0);
		if (d > 0) {
			id1 = i;
			id2 = iltsearch(i, -1);
			if (id2) break;
		}
	}
	if (id1 < 0){
		fprintf(stderr, "Fatal: cannot find matched data in two files\n");
		exit(-1);
	}

	if (ilt[id1].flag == TYPE_LEFT) {
		diff = packet[id1].captime + d - packet2[id2].captime;
	} else {
		diff = packet[id1].captime - d - packet2[id2].captime;
	}

	for (i = 0; i < pktcount; i ++){
		id2 = iltsearch(i, diff);
		if (id2 != -1) {
			if (ilt[i].flag == TYPE_LEFT) {
				/* adjust recvtime */
				ilt[i].recvtime = packet2[id2].captime + diff;
			} else {
				/* adjust sendtime */
				ilt[i].sendtime = packet2[id2].captime + diff;
			}
			ilt[i].delay = ilt[i].recvtime - ilt[i].sendtime;
		} else {
			ilt[i].state = STAT_LOST;
		}
	}
}

/*
 * create iltdata from sampled packets in single file
 */
void
create_iltdata()
{
	int i, j, k, target, highest_ack = -1, nid;
	u_long cliaddr6[4], targetaddr6[4];
	float ackcaptime, tmp, mrtt = -1;
	int csflag, csidx;
	int found_retr, recover;
	long rseq1 = 0, rseq2 = 0;
	char * create_msg();

	/* reordered packet check */
	for (i = 0; i < pktcount; i ++){
		if (!packet[i].datalen) continue;
		if (!memcmp(packet[i].src6_addr, packet[0].src6_addr, 16)){
			if (packet[i].seq >= rseq1) rseq1 = packet[i].seq;
			else {
				packet[i].state = STAT_IGN | STAT_REORDER;
			}
		} else { 
			if (packet[i].seq > rseq2) rseq2 = packet[i].seq;
			else {
				packet[i].state = STAT_IGN | STAT_REORDER;
			}
		}
	}

	/* retransmit packet check */
	for (i = 0; i < pktcount; i ++){
		found_retr = 0;
		for (j = i+1; j < pktcount; j ++){
			if (!memcmp(packet[i].src6_addr, packet[j].src6_addr, 16)
				&& (packet[i].datalen || (packet[i].flags & TH_SYN))){ 
				if (packet[i].seq == packet[j].seq) {
					packet[i].state = STAT_LOST;
					packet[j].state = STAT_RETRANS;
					for (k = i; k <= j; k ++)
						packet[k].state |= STAT_IGN;
					found_retr = 1;
					recover = packet[j].seq +1;
				}
			}
			if (found_retr == 1) {
				packet[j].state |= STAT_IGN;
				if (!memcmp(packet[i].src6_addr, packet[j].dst6_addr, 16)){
					if (packet[j].ack > recover) {
						found_retr = 0;
						packet[j].state = 0;
					} 
				}
			}
			if (!memcmp(packet[i].src6_addr, packet[j].src6_addr, 16)
				&& !packet[j].datalen && (packet[j].flags & TH_ACK)){ 
				if (packet[i].ack == packet[j].ack) {
					packet[i].state |= STAT_DUPACK;
					packet[j].state |= STAT_DUPACK;
					for (k = i; k <= j; k ++)
						packet[k].state |= STAT_IGN;
				}
			}
		}
	}

	for (i = 0; i < pktcount; i ++){
		packet[i].gap = packet[i].rtt = -1;
		packet[i].ackid = 0;
		if (packet[i].state) continue;
		if (!packet[i].state && 
					(packet[i].datalen || (packet[i].flags & TH_SYN))) {
			/* find ACK */
			target = packet[i].seq + packet[i].datalen 
						+ ((packet[i].flags & TH_SYN)?1:0);
			for (j = i+1; j < pktcount; j ++){
				if (packet[j].ack == target && 
					!memcmp(packet[i].src6_addr, packet[j].dst6_addr, 16)){
					packet[i].rtt = packet[j].captime - packet[i].captime;
					packet[i].ackid = j;
					packet[j].seqid = i;

					if (packet[i].rtt > mrtt) mrtt = packet[i].rtt; 
					break;
				} else {
					if (packet[j].ack > target){
						packet[i].rtt = -1;
						packet[i].ackid = j;
						packet[j].seqid = i;
						break;
					}
				}
			}
		}
		
		/* XXX, need to be modify? */
		if (packet[i].ack > highest_ack){
			highest_ack = packet[i].ack;
			memcpy(&targetaddr6, packet[i].dst6_addr, 16);
			ackcaptime = packet[i].captime;
			nid = i;
		}
		if (!(memcmp(&targetaddr6, packet[i].src6_addr, 16)) &&
			packet[i].seq == highest_ack) {
				packet[i].gap = packet[i].captime - ackcaptime;
				packet[i].newackid = nid;
				if (packet[i].gap > mrtt) mrtt = packet[i].gap; 
		}
	}

	for (i = 0; i < pktcount; i ++){
		if (packet[i].state & STAT_LOST) continue;
		if (!packet[i].datalen && !packet[i].seqid &&
						!(packet[i].flags & TH_SYN)){
			target = 0;
			for (j = i-1; j > 0; j --){
				if (packet[j].state & STAT_LOST) continue;
				if (packet[i].captime - packet[j].captime > mrtt) break;
				if (!packet[j].ackid && packet[j].datalen){
					target = j;
				}
			}
			if (target) {
				packet[target].rtt = packet[i].captime - packet[target].captime;
				packet[target].ackid = i;
				packet[i].seqid = target;
			}
		}
	}

	csidx = 0;
	for (i = 0; i < pktcount; i ++){
		if (packet[i].rtt > 0) {
			csidx = i;
			break;
		}
	}

	if (packet[csidx].rtt < calculate_delay(csidx, 1)) {
		memcpy(&cliaddr6, packet[csidx].dst6_addr, 16);
		csflag = 0;
	} else {
		memcpy(&cliaddr6, packet[csidx].src6_addr, 16);
		csflag = 1;
	}

	ilt = (struct iltdata *)malloc(sizeof(struct iltdata) * pktcount);
	for (i = 0; i < pktcount; i ++){
		ilt[i].delay = calculate_delay(i, 0);
		ilt[i].seq = packet[i].seq;
		ilt[i].state = (packet[i].datalen ? STAT_DATA : STAT_ACK);
		if (!memcmp(packet[i].src6_addr, &cliaddr6, 16)){
	    	ilt[i].flag = TYPE_LEFT;
			ilt[i].sendtime = packet[i].captime;
			ilt[i].recvtime = packet[i].captime + ilt[i].delay;
		} else {
	    	ilt[i].flag = TYPE_RIGHT;
			ilt[i].sendtime = packet[i].captime - ilt[i].delay;
			ilt[i].recvtime = packet[i].captime;
		}
		if (packet[i].state % STAT_IGN) 
			ilt[i].state = packet[i].state % STAT_IGN;	

		sprintf(ilt[i].text, " %ld:%ld(%d) ack %ld win %d ", 
			packet[i].seq, packet[i].seq + packet[i].datalen,
			packet[i].datalen, packet[i].ack, packet[i].win);

		ilt[i].data = packet[i].data;
		create_msg(i, 1); /* to learn seq and ack number */
	}

	/* adjust packet based on the combination of data and ack */
	for (i = 0; i < pktcount; i ++){
		if (packet[i].ackid && 
				ilt[i].recvtime > ilt[packet[i].ackid].sendtime) {
			if ((!memcmp(packet[packet[i].ackid].dst6_addr, &cliaddr6, 16)) ||
			   (!memcmp(packet[i].src6_addr, &cliaddr6, 16))){
				/* 
				   data sendtime and ack recvtime is reliable 
				   and ack sendtime is mostly reliable 
			     */
				tmp = ilt[i].recvtime;
				ilt[i].recvtime = ilt[packet[i].ackid].sendtime;
				ilt[i].delay = ilt[i].recvtime - ilt[i].sendtime;

#if 1
				if (ilt[i].delay < 0) {
					ilt[i].recvtime = tmp;
					ilt[i].delay = ilt[i].recvtime - ilt[i].sendtime;
				}
#else
				if (ilt[i].delay < 0) {
					/* OK, we need to adjust ack sendtime */
					ilt[i].recvtime = tmp;
					ilt[i].delay = ilt[i].recvtime - ilt[i].sendtime;
					ilt[packet[i].ackid].sendtime = ilt[i].recvtime;
					ilt[packet[i].ackid].delay = ilt[packet[i].ackid].recvtime - 
								ilt[packet[i].ackid].sendtime;
					if (ilt[packet[i].ackid].delay < 0) {
						/* we need to adjust ack sendtime and data recvtime */
						tmp = (ilt[packet[i].ackid].recvtime + ilt[i].sendtime) / 2.0;
						ilt[i].recvtime = ilt[packet[i].ackid].sendtime = tmp;
						ilt[i].delay = ilt[i].recvtime - ilt[i].sendtime;
						ilt[packet[i].ackid].delay = ilt[packet[i].ackid].recvtime - 
							ilt[packet[i].ackid].sendtime;
					}								
				}
#endif
			} else {
				/* this never happens */		
				exit(-1);						
			}
		}
	}

#if 0
	/* adjust packet based on newack, not implemented yet */
	for (i = 0; i < pktcount; i ++){
		if (packet[i].newackid && 
			ilt[i].sendtime < ilt[packet[i].newackid].recvtime) {
			/* adjust */
			tmp = (ilt[i].recvtime - ilt[packet[i].newackid].sendtime)/2.0;
			ilt[packet[i].newackid].recvtime = 
					ilt[packet[i].newackid].sendtime + tmp;
			ilt[packet[i].newackid].delay = ilt[packet[i].newackid].recvtime -
									ilt[packet[i].newackid].sendtime;

			ilt[i].sendtime = ilt[i].recvtime - tmp;
			ilt[i].delay = ilt[i].recvtime - ilt[i].sendtime;
		}
	}
#endif

	/* debug */
#if 0
	for (i = 0; i < pktcount; i ++){
		printf("\n\n%d captime %f rtt %f gap %f\n", i, packet[i].captime, packet[i].rtt, packet[i].gap);	
		printf("   src %x dst %x\n", packet[i].src6_addr[3], packet[i].dst6_addr[3]);	
		printf("   sport %d dport %d\n", packet[i].src_port, packet[i].dst_port);	
		printf("   seq %d ack %d\n", packet[i].seq, packet[i].ack);	
		printf("   len %d \n", packet[i].datalen);	
		printf("   ackid %d \n", packet[i].ackid);	
		printf("   status %d \n", packet[i].state);	
		printf("%d \n", i);	
		printf("   type %d \n", ilt[i].flag);	
		printf("   send %f \n", ilt[i].sendtime);	
		printf("   recv %f \n", ilt[i].recvtime);	
		printf("   delay %f \n", ilt[i].delay);	
		printf("   text %s \n", ilt[i].text);	
	}
#endif
}

float
calculate_delay(i1, clear)
	int i1;
	int clear;
{
	int i2, i3;
	float ret;

	i2 = i1 -10; if (i2 < 0) i2 = 0;
	i3 = i2 + 10;

	ret = calculate_delay2(i2, i3, packet[i1].datalen, clear);

	return ret;
}

float 
calculate_delay2(start, end, len, clear)
	int start, end, len, clear;
{
	int i, j, cnt = 0, gcnt = 0;
	int rlenmtx[MAXSAMPLE], glenmtx[MAXSAMPLE], candlen;
	float rttmtx[MAXSAMPLE], gapmtx[MAXSAMPLE], rtt0 = -1, rtt1 = -1, candrtt = -1; 
	static float last_rtt0 =-1, last_rtt1 = -1;

	if (clear) last_rtt0 = last_rtt1 = -1;
	for (i = start; i < end; i ++){
		if (packet[i].state & STAT_IGN) continue;
		if (packet[i].rtt > 0) {
			for (j = 0; j < cnt; j ++){
				if (packet[j].state) continue;
				if (rlenmtx[j] == packet[i].datalen) {
					/* 
					 * we already sampled this datalen, 
					 * smooth it by moving average
					 */ 
					rttmtx[j] = rttmtx[j] * 0.9 + packet[i].rtt * 0.1;
					break;
				}
			}
			if (j == cnt) {
				/* this is new sample */
				rlenmtx[cnt] = packet[i].datalen;
				rttmtx[cnt] = packet[i].rtt;
				cnt ++;
			}
		}

		if (packet[i].gap > 0) {
			for (j = 0; j < gcnt; j ++){
				if (packet[j].state) continue;
				if (glenmtx[j] == packet[i].datalen) {
					/* 
					 * we already sampled this datalen, 
					 * smooth it by moving average
					 */
					gapmtx[j] = gapmtx[j] * 0.9 + packet[i].gap * 0.1;
					break;
				}
			}
			if (j == gcnt) {
				/* this is new sample */
				glenmtx[gcnt] = packet[i].datalen;
				gapmtx[gcnt] = packet[i].gap;
				gcnt ++;
			}
		}
	}

	for (i = 0; i < cnt; i ++){
		if (rlenmtx[i] == 0){
			rtt0 = rttmtx[i];
			break;
		}
	}
	for (i = 0; i < gcnt; i ++){
		if (glenmtx[i] == 0 && gapmtx[i] > rtt0){
			rtt0 = gapmtx[i];
			break;
		}
	}
	for (i = 0; i < cnt; i ++){
		if (rlenmtx[i] == len){
			rtt1 = rttmtx[i];
			break;
		}
	}
	for (i = 0; i < gcnt; i ++){
		if (glenmtx[i] == len && gapmtx[i] > rtt1){
			rtt1 = gapmtx[i];
			break;
		}
	}

#if 0
	/* this is an experimental algorithm */
	if (rtt1 == -1 && len){
		/* rtt1 == -1 means we cannot find appropriate rtt for the len;
		 * hence, we need to find good candidate rtt here 
		 * */
		candlen = -1;
		candrtt = -1;
		for (i = 0; i < cnt; i ++){
			if (candlen < 0){ 
				candlen = rlenmtx[i];
				candrtt = rttmtx[i];
			} else {
				if (abs(rlenmtx[i] - len) < abs(candlen - len)){
					candlen = rlenmtx[i];
					candrtt = rttmtx[i];
				}
			}
		}	
	}
    if (candlen > 0) rtt1 = candrtt;
#endif

	if (rtt0 < 0) rtt0 = last_rtt0;
	else if (rtt0 > last_rtt0) last_rtt0 = rtt0;
	if (rtt0 < 0) rtt0 = last_rtt0 = rtt1;

	if (rtt1 < rtt0 && len > 0) rtt1 = last_rtt1;
	if (rtt1 < rtt0) rtt1 = last_rtt0;


	if (len > 0) {
		if (rtt1 < 0) rtt1 = last_rtt1;
		else last_rtt1 = rtt1;
	} else 
		if (rtt1 < 0) rtt1 = last_rtt0;

	return rtt1 - rtt0/2.0;

#if 0
	/* not implemented yet */

	/* sort data */
	for (i = 0; i < cnt-1; i ++){
		for (j = 0; j < cnt-1; j ++){
			if (rlenmtx[j] > rlenmtx[j+1]){
				tmp1 = rlenmtx[j];
				tmp2 = rttmtx[j];
				rlenmtx[j] = rlenmtx[j+1];
				rttmtx[j] = rttmtx[j+1];
				rlenmtx[j+1] = tmp1;
				rttmtx[j+1] = tmp2;
			}
		}
	}

	/* perform linear squeare */
	for (i = 0; i < cnt; i++) {
		sum_xy += rlenmtx[i] * rttmtx[i];
		sum_x += rlenmtx[i];
		sum_y += rttmtx[i];
		sum_x2 += rlenmtx[i] * rlenmtx[i];
	}
	a = (cnt * sum_xy - sum_x * sum_y) / (cnt * sum_x2 - sum_x * sum_x);
	b = (sum_x2 * sum_y - sum_xy * sum_x) / (cnt * sum_x2 - sum_x* sum_x);
#endif
}

#define NUMCAND 100
static int 
iltsearch(id, esttime)
	int id;
	float esttime;
{
	int i, candid[NUMCAND], cc = 0, minid = -1;
	float candd[NUMCAND], min; 

	/* if we have id, use it for search packet */
	if (packet[id].id) {
		for (i = 0; i < pktcount2; i ++){
			if (packet2[i].id == packet[id].id)		
				return i;
		}
		return -1;
	}

	candid[0] = -1;
	for (i = 0; i < pktcount2; i ++){
		if (packet[id].seq == packet2[i].seq && 
				packet[id].ack == packet2[i].ack && 
				packet[id].win == packet2[i].win) {
			if (esttime > 0) {	
				candid[cc] = i;
				candd[cc] = abs(packet2[i].captime - esttime);
				cc ++;
			} else 
				return i;
		}
	}
	if (candid[0] < 0) return -1; /* we cannot find candidate */	

	min = candd[0];
	for (i = 1; i < cc; i ++){
		if (candd[i] < min) {
			min = candd[i];
			minid = i;
		}
	}
	return minid;
}

void
Usage()
{
	char	name[] = PROG_NAME;

	fprintf(stderr, "Usage: %s [opts] file [file]\n", name);
	fprintf(stderr, "\t-V: be verbose\n");
	fprintf(stderr, "\t-g <geometry>: specify window geometry\n");
	fprintf(stderr, "\t-v: show version number and quit\n");
	fprintf(stderr, "\t-h: display this help message\n");
#if 0
	fprintf(stderr, "\t-T [b|a]: Specify file type. bin or ascii\n");
#endif

	exit(0);
}
