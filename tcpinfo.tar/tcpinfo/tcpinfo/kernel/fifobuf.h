/* $Id: fifobuf.h 1 2006-08-27 15:27:37Z aaron $ - vim:sw=8 tw=72
 *
 * Interface file for the FIFO buffer. The FIFO buffer is completely
 * interrupt safe (i.e. it will never schedule).
 *
 * Author:	Aaron Isotton <aaron@isotton.com>
 */ 

#ifndef TCPINFO_FIFOBUF_H
#define TCPINFO_FIFOBUF_H

#include <linux/types.h>

struct fifobuf 
{
	char *buf;
	size_t size, rpos, wpos;
};
typedef struct fifobuf fifobuf_t;

void fifobuf_init(fifobuf_t *fb);
void fifobuf_free(fifobuf_t *fb);
size_t fifobuf_used(fifobuf_t *fb);
int fifobuf_put(fifobuf_t *fb, const char *data, size_t size);
size_t fifobuf_get_user(fifobuf_t *fb, char *data, size_t size);
void fifobuf_remove(fifobuf_t *fb, size_t size);

#endif
