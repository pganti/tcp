/* $Id: fifobuf.c 1 2006-08-27 15:27:37Z aaron $ - vim:sw=8 tw=72
 *
 * Implementation of the FIFO buffer. The FIFO buffer is completely
 * interrupt safe (i.e. it will never schedule).
 *
 * Author:	Aaron Isotton <aaron@isotton.com>
 */
#include "fifobuf.h"

#include <linux/types.h>
#include <linux/slab.h>
#include <asm/uaccess.h>

/*---------------------------------------------------------------------
 * Memory allocation parameters.
 *---------------------------------------------------------------------*/
#define INCREASE_FACTOR 2
#define INCREASE_CONSTANT 2000
#define DECREASE_FACTOR 4
#define DECREASE_CONSTANT 5000

/* Check the allocator constants for validity */
#if INCREASE_FACTOR >= DECREASE_FACTOR
	#error INCREASE_CONSTANT must be smaller than DECREASE_FACTOR
#endif

#if INCREASE_CONSTANT <= 0
	#error INCREASE_CONSTANT must be > 0
#endif

#if INCREASE_CONSTANT >= DECREASE_CONSTANT
	#error INCREASE_CONSTANT must be smaller than DECREASE_CONSTANT
#endif


/*----------------------------------------------------------------------
 * Helper functions; there are min/max *macros* in the kernel, but we
 * need functions to avoid double evaluation. 
 *----------------------------------------------------------------------*/
static inline size_t minf(size_t a, size_t b) 
{
	return a < b ? a : b;
}

static inline size_t maxf(size_t a, size_t b) 
{
	return a > b ? a : b;
}


/*----------------------------------------------------------------------
 * Initialize fb.
 *----------------------------------------------------------------------*/
void fifobuf_init(fifobuf_t *fb) 
{
	fb->buf = NULL;
	fb->size = fb->rpos = fb->wpos = 0;
}


/*----------------------------------------------------------------------
 * Free all resources used for fb; fb will be empty and usable after.
 *----------------------------------------------------------------------*/
void fifobuf_free(fifobuf_t *fb) 
{
	kfree(fb->buf);
	fifobuf_init(fb);
}


/*----------------------------------------------------------------------
 * Return the number of bytes in fb.
 *----------------------------------------------------------------------*/
size_t fifobuf_used(fifobuf_t *fb) 
{
	if (fb->size == 0) return 0;
	return (fb->size + fb->wpos - fb->rpos) % fb->size;
}


/*----------------------------------------------------------------------
 * Return the number of available bytes (free space) in fb.
 *----------------------------------------------------------------------*/
size_t fifobuf_avail(fifobuf_t *fb) 
{
	return fb->size - fifobuf_used(fb);
}


/*----------------------------------------------------------------------
 * Resize the allocated memory in fb. 
 * returns 0 in case of success.
 *----------------------------------------------------------------------*/
static int fifobuf_reallocate(fifobuf_t *fb, size_t new_size) 
{
	char *tmp;

	if (new_size <= fifobuf_used(fb)) {
		printk(KERN_WARNING "tcpinfo: requested to small FIFO, "
				"ignoring\n");
		return 0;
	}

	printk(KERN_DEBUG "tcpinfo: changing FIFO size ("
	       "used = %u, size = %u, new = %u)\n",
	       fifobuf_used(fb), fb->size, new_size);

	/* Allocate the new memory chunk */
	tmp = kmalloc(new_size, GFP_ATOMIC);
	if (!tmp) return -ENOMEM;

	/* Two cases: either the existing data is wrapped around the end
	 * of the cyclic buffer, or it isn't */
	if (fb->wpos >= fb->rpos) {
		/* not wrapped, one copy */
		memcpy(tmp, fb->buf + fb->rpos, fb->wpos - fb->rpos);
	}
	else {
		/* Wrapped, two copies */
		size_t n;

		n = fb->size - fb->rpos;
		memcpy(tmp, fb->buf + fb->rpos, n);
		memcpy(tmp + n, fb->buf, fb->wpos);
	}

	/* Free the old buffer and set the new parameters */
	kfree(fb->buf);
	fb->buf = tmp;
	fb->wpos = fifobuf_used(fb);
	fb->rpos = 0;
	fb->size = new_size;

	return 0;
}


/*----------------------------------------------------------------------
 * Put the given data into the FIFO.
 * Returns 0 in case of success, an error code in case of failure.
 * In case of failure, fb is not touched at all
 *----------------------------------------------------------------------*/
int fifobuf_put(fifobuf_t *fb, const char *data, size_t size) 
{
	/* Reallocate memory if necessary */
	if (size >= fifobuf_avail(fb)) {
		size_t new_size;
		int ret;

		new_size = maxf(fifobuf_used(fb) + size + INCREASE_CONSTANT,
				fb->size * INCREASE_FACTOR);
		ret = fifobuf_reallocate(fb, new_size);
		if (ret) return ret;
	}

	/* Copy the data */
	if (fb->wpos + size <= fb->size) {
		memcpy(fb->buf + fb->wpos, data, size);
	}
	else {
		size_t n;

		n = fb->size - fb->wpos;
		memcpy(fb->buf + fb->wpos, data, n);
		memcpy(fb->buf, data + n, size - n);
	}

	fb->wpos = (fb->wpos + size) % fb->size;

	return 0;
}


/*----------------------------------------------------------------------
 * Write the first size bytes from the FIFO to data (which should be in user 
 * space).
 *
 * Returns the number of bytes copied. this may be smaller than size if the
 * FIFO didn't contained less data than size.
 *
 * The data is *not* removed from the FIFO; if you call this function twice,
 * it will copy the same data twice. use fifobuf_remove to remove the data.
 *----------------------------------------------------------------------*/
size_t fifobuf_get_user(fifobuf_t *fb, char *data, size_t size) 
{
	size = minf(size, fifobuf_used(fb));

	if (fb->rpos + size <= fb->size) {
		return size - copy_to_user(data, fb->buf + fb->rpos, size);
	}
	else {
		size_t n, missing;

		n = fb->size - fb->rpos;
		missing = copy_to_user(data, fb->buf + fb->rpos, n);
		if (missing) return n - missing;

		return size - copy_to_user(data + n, fb->buf, size - n);
	}
}


/*----------------------------------------------------------------------
 * Remove the first size bytes from the FIFO.
 *
 * Behavior is undefined if the FIFO contains less than size bytes.
 *----------------------------------------------------------------------*/
void fifobuf_remove(fifobuf_t *fb, size_t size)
{
	/* increase the read pointer */
	fb->rpos = (fb->rpos + size) % fb->size;

	if (fifobuf_used(fb) + DECREASE_CONSTANT 
			< fb->size / DECREASE_FACTOR) {
		/* reallocate a smaller chunk of memory. we don't care if this 
		 * fails */
		fifobuf_reallocate(fb, fb->size / DECREASE_FACTOR);
	}
}
