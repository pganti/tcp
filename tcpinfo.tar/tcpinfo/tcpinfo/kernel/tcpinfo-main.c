/* $Id: tcpinfo-main.c 1 2006-08-27 15:27:37Z aaron $ - vim:sw=8 tw=72
 *
 * The tcpinfo kernel module implementation.
 *
 * Author:	Aaron Isotton <aaron@isotton.com>
 */

#include "../include/tcpinfo.h"
#include "fifobuf.h"
#include <linux/init.h>
#include <linux/config.h>
#include <linux/module.h>
#include <linux/kernel.h>	/* printk() */
#include <linux/fs.h>		/* everything... */
#include <linux/errno.h>	/* error codes */
#include <linux/types.h>	/* size_t */
#include <asm/msr.h>		/* rdtsc */
#include <asm/timex.h>		/* cpu_khz */
#include <linux/tcp.h>		/* TCP stuff */

/*----------------------------------------------------------------------
 * Prototypes
 *----------------------------------------------------------------------*/
static int tcpinfo_init(void);
static void tcpinfo_exit(void);
static ssize_t tcpinfo_read(struct file *filp, char *buf, size_t count, 
	loff_t *f_pos);
static int tcpinfo_open(struct inode *inode, struct file *filp);
static int tcpinfo_release(struct inode *inode, struct file *filp);

static int tcpinfo_append_data(const char *data, size_t size);
static void tcpinfo_snd_hook(const struct tcp_sock *tp,
		             const struct tcphdr *th);
static void tcpinfo_rcv_hook(const struct tcp_sock *tp,
		             const struct tcphdr *th);

/*----------------------------------------------------------------------
 * Globals
 *----------------------------------------------------------------------*/

static struct file_operations tcpinfo_fops = 
{
	.owner = THIS_MODULE,
	.read = tcpinfo_read,
	.open = tcpinfo_open,
	.release = tcpinfo_release
};

/* The device major number */
static int tcpinfo_major = 60; 

/* A lock for all globals */
static spinlock_t tcpinfo_lock = SPIN_LOCK_UNLOCKED; 

/* The FIFO buffer storing the data */
static fifobuf_t buffer;

/* Whether anybody has opened the device */
static volatile unsigned device_is_open = 0;

/* The wait queue for blocking I/O */
DECLARE_WAIT_QUEUE_HEAD(tcpinfo_wait_queue); 


/*----------------------------------------------------------------------
 * Initialize the module.
 *----------------------------------------------------------------------*/
static int tcpinfo_init(void) 
{
	int ret;

	/* Register the device */
	ret = register_chrdev(tcpinfo_major, "tcpinfo", &tcpinfo_fops);
	if (ret < 0) {
		printk(KERN_ERR "tcpinfo: cannot get major number %d\n", 
				tcpinfo_major);
		return ret;
	}

	/* Register the tcp hooks */
	tcp_snd_hook_register(&tcpinfo_snd_hook);
	tcp_rcv_hook_register(&tcpinfo_rcv_hook);

	printk(KERN_INFO "tcpinfo: loaded\n");
	return 0;
}


/*----------------------------------------------------------------------
 * Uninitialize the module
 *----------------------------------------------------------------------*/
static void tcpinfo_exit(void) 
{
	/* Unregister the tcp hooks */
	tcp_snd_hook_register(NULL);
	tcp_rcv_hook_register(NULL);

	/* Unregister the device */
	unregister_chrdev(tcpinfo_major, "tcpinfo");

	/* Free the buffer - shouldn't be necessary, but I prefer being on
	 * the safe side */
	fifobuf_free(&buffer);

	printk(KERN_INFO "tcpinfo: unloaded\n");
}


/*----------------------------------------------------------------------
 * The read callback function
 *----------------------------------------------------------------------*/
static ssize_t tcpinfo_read(struct file *filp, char *buf, size_t count, 
		loff_t *f_pos) 
{
	int ret;

	if (count == 0) return 0;

	/* Block if there is no data available */
	ret = wait_event_interruptible(tcpinfo_wait_queue,
			fifobuf_used(&buffer));

	/* Return if we were interrupted by a signal; otherwise, some data 
	 * is available */
	if (ret) return ret;

	/* Acquire the lock */
	spin_lock(&tcpinfo_lock);

	/* Find out how many bytes we should copy */
	count = min(fifobuf_used(&buffer), count);

	/* Copy the data to user space and remove it from the buffer */
	count = fifobuf_get_user(&buffer, buf, count);
	fifobuf_remove(&buffer, count);
	*f_pos += count;

	/* Release the lock */
	spin_unlock(&tcpinfo_lock);

	return count;
}


/*----------------------------------------------------------------------
 * Called when somebody wants to open the device
 *----------------------------------------------------------------------*/
static int tcpinfo_open(struct inode *inode, struct file *filp) 
{
	int retval = 0;

	/* Check whether the permissions are ok */
	if ((filp->f_mode & FMODE_READ) == 0) return -EINVAL;
	if (filp->f_mode & FMODE_WRITE) return -EINVAL;

	/* Acquire the lock */
	spin_lock(&tcpinfo_lock);

	/* See whether the device is already opened; we only allow one program
	 * to open the device at once */
	if (device_is_open) 
		retval = -EBUSY;
	else {
		device_is_open = 1;

		/* Initialize the FIFO */
		fifobuf_init(&buffer);
	}

	/* Release the lock */
	spin_unlock(&tcpinfo_lock);

	return retval;
}


/*----------------------------------------------------------------------
 * Called when somebody closes the device.
 *----------------------------------------------------------------------*/
static int tcpinfo_release(struct inode *inode, struct file *filp) 
{
	/* Acquire the lock */
	spin_lock(&tcpinfo_lock);

	/* Free the FIFO and set the open flag to 0 */
	fifobuf_free(&buffer);
	device_is_open = 0;

	/* Release the lock */
	spin_unlock(&tcpinfo_lock);

	return 0;
}


/*----------------------------------------------------------------------
 * Called from tcpinfo_hook to append data to the FIFO.
 *----------------------------------------------------------------------*/
static int tcpinfo_append_data(const char *data, size_t size) 
{
	int do_wakeup = 0;

	/* Acquire the lock */
	spin_lock(&tcpinfo_lock);

	/* Only do anything if size > 0 and the device is opened by 
	 * anybody */
	if (size && device_is_open) {
		int ret;

		/* Append the new data */
		ret = fifobuf_put(&buffer, data, size);
		if (ret) {
			spin_unlock(&tcpinfo_lock);
			return ret;
		}

		do_wakeup = 1;
	}

	/* Release the lock */
	spin_unlock(&tcpinfo_lock);

	/* Wake up all processes blocking on tcpinfo_read */
	if (do_wakeup)
		wake_up_interruptible(&tcpinfo_wait_queue);

	return 0;
}


/*----------------------------------------------------------------------
 * The callback function. This is not hooked directly into the TCP
 * module but called from tcpinfo_snd_hook and tcpinfo_rcv_hook.
 *
 * This is called from an interrupt handler!
 *----------------------------------------------------------------------*/
static void tcpinfo_hook(const struct tcp_sock *tp,
		         const struct tcphdr *th,
			 enum tcpinfo_packet_direction direction)
{
	int ret;
	struct tcpinfo_packet packet;
	unsigned long long cycles;
	const struct inet_sock *inet;

	/* Magic number and size */
	packet.magic = TCPINFO_MAGIC_NUMBER;
	packet.size = sizeof(packet);

	/* Get the current CPU cycles; we need accurate timing information,
	 * and the TSC is both fast and the most precise we can get */
	rdtscll(cycles);
	if (cycles == 0)
		printk(KERN_INFO "tcpinfo: rdtscll returned 0\n");
	packet.cycles = cycles;
	packet.cpu_khz = cpu_khz;

	/* Packet direction */
	packet.direction = direction;

	/* Local and remote address and port */
	inet = &tp->inet_conn.icsk_inet;
	packet.local_addr = inet->saddr;
	packet.remote_addr =inet->daddr;
	packet.local_port = inet->sport;
	packet.remote_port = inet->dport;

	/* Sequence number and ACK sequence number */
	packet.seq = ntohl(th->seq);
	packet.ack_seq = ntohl(th->ack_seq);

	/* Congestion window parameters */
	packet.snd_cwnd = tp->snd_cwnd;
	packet.snd_cwnd_used = tp->snd_cwnd_used;
	packet.snd_cwnd_cnt = tp->snd_cwnd_cnt;
	packet.rcv_wnd = tp->rcv_wnd;

	/* RTT parameters */
	packet.rtt_smoothed = tp->srtt;
	packet.rtt_medium_deviation = tp->mdev;

	/* Add the packet to the FIFO */
	ret = tcpinfo_append_data((const char*) &packet, sizeof(packet));

	if (ret < 0) 
		printk(KERN_ERR "tcpinfo: cannot add sock structure to "
		                "buffer: %i\n",	ret);
}

/*----------------------------------------------------------------------
 * The send callback hooked into the TCP module.
 * This is called from an interrupt handler!
 *----------------------------------------------------------------------*/
static void tcpinfo_snd_hook(const struct tcp_sock *tp,
		         const struct tcphdr *th)
{
	tcpinfo_hook(tp, th, TCPINFO_PACKET_DIRECTION_SND);
}

/*----------------------------------------------------------------------
 * The receive callback hooked into the TCP module.
 * This is called from an interrupt handler!
 *----------------------------------------------------------------------*/
static void tcpinfo_rcv_hook(const struct tcp_sock *tp,
		         const struct tcphdr *th)
{
	tcpinfo_hook(tp, th, TCPINFO_PACKET_DIRECTION_RCV);
}

/*----------------------------------------------------------------------
 * Module magic
 *----------------------------------------------------------------------*/

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Aaron Isotton");

module_init(tcpinfo_init);
module_exit(tcpinfo_exit);
