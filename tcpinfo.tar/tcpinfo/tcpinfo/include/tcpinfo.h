/* $Id: tcpinfo.h 1 2006-08-27 15:27:37Z aaron $ - vim:sw=8 tw=72
 *
 * This file defines the interface between the tcpinfo kernel module and
 * userland.
 *
 * Author:	Aaron Isotton <aaron@isotton.com>.
 */

#ifndef TCPINFO_TCPINFO_H
#define TCPINFO_TCPINFO_H

/* We need the uintXX_t types, which are defined in stdint.h. The kernel
 * doesn't like C99 and thus we're forced to use linux/types.h instead.
 */
#ifdef __KERNEL__
    #include <linux/types.h>
#else
    #include <stdint.h>
#endif


/* This is a magic number with no meaning, which should be changed
 * whenever the interface changes. This is to make sure that the kernel
 * module and the userland application are using the same interface.
 *
 * Some magic numbers for future use:
 *
 * 0xf47da306LU 0xc1699361LU 0xce18a0d8LU
 * 0xa0c4616cLU 0xf18ec91cLU 0x87e3fef2LU 0xb77b0219LU 0x9917805dLU
 *
 * You can generate more suitable magic numbers using this python
 * one-liner:
 *
 * import random; print '0x%xLU' % random.randrange(2**31, 2**32)
 */
#define TCPINFO_MAGIC_NUMBER 0xfe783941LU

/*
 * Constants for the packet direction (i.e. whether a packet was sent or 
 * received.
 */ 
enum tcpinfo_packet_direction {
    TCPINFO_PACKET_DIRECTION_RCV,
    TCPINFO_PACKET_DIRECTION_SND
};

/*----------------------------------------------------------------------
 * The kernel module writes a sequence of struct tcpinfo_packet to its
 * device; programs in userland can read from the device and access the
 * members of this structure.
 *----------------------------------------------------------------------*/
struct tcpinfo_packet {
    /* This should always be TCPINFO_MAGIC_NUMBER; the kernel should set
     * it and the user should check it */
    uint32_t magic;

    /* This should be sizeof(tcpinfo_packet); the same logic as for
     * magic applies here. This 'more or less' checks whether the
     * padding is the same (which shouldn't happen anyway thanks to
     * __attribute__((packed))). */
    uint32_t size;

    /* Timing information; cycles / (cpu_khz * 1000.) will give you the
     * number of seconds since system start in CPU cycle resolution */
    uint64_t cycles; 
    uint64_t cpu_khz;

    /* The direction of the packet (i.e. if incoming or outgoing) */
    enum tcpinfo_packet_direction direction;

    /* The local address/port of the connection */
    uint32_t local_addr;
    uint16_t local_port;

    /* The remote address/port of the connection */
    uint32_t remote_addr;
    uint16_t remote_port;

    /* The sequence number of the packet */
    uint32_t seq;

    /* The ACK number of the packet */
    uint32_t ack_seq;

    /* Some TCP parameters */
    uint32_t snd_cwnd;
    uint32_t snd_cwnd_used;
    uint32_t snd_cwnd_cnt;
    uint32_t rcv_wnd;

    /* Some RTT parameters */
    uint32_t rtt_smoothed;		/* Smoothed RTT (<<8) */
    uint32_t rtt_medium_deviation;	/* Medium deviation (also <<8) (?) */
} __attribute__((packed));

#endif
