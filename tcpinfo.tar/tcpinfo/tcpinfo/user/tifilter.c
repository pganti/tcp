/* $Id: tifilter.c 1 2006-08-27 15:27:37Z aaron $ - vim:sw=4 tw=72
 *
 * tifilter reads a sequence of struct tcpinfo_packet from a file or
 * standard input, filters them, and writes a sequence of struct 
 * tcpinfo_packet to standard output.
 *
 * Author:	Aaron Isotton <aaron@isotton.com>
 */

#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <getopt.h>

#include "../include/tcpinfo.h"

/*----------------------------------------------------------------------
 * Constants
 *----------------------------------------------------------------------*/
#define MIN_PORT 0	/* The smallest valid tcp port */
#define MAX_PORT 65535	/* The largest valid tcp port */

/*----------------------------------------------------------------------
 * Externs
 *----------------------------------------------------------------------*/
extern int optind;
extern char *optarg;

/*----------------------------------------------------------------------
 * Types
 *----------------------------------------------------------------------*/
struct filter {
    uint32_t local_addr, local_addr_mask;
    uint16_t min_local_port, max_local_port;

    uint32_t remote_addr, remote_addr_mask;
    uint16_t min_remote_port, max_remote_port;
};

/*----------------------------------------------------------------------
 * Globals - volatile because they're shared between the main thread and
 * the signal handler.
 *----------------------------------------------------------------------*/
static volatile int quit = 0;			/* The quit flag */
static volatile int retval = EXIT_SUCCESS;	/* The return value of main() */
static volatile char *progname;

/*----------------------------------------------------------------------
 * Command line options. Extend as you wish.
 *----------------------------------------------------------------------*/
enum {
    OPTION_HELP = 1,
    OPTION_LOCAL_ADDRESS,
    OPTION_REMOTE_ADDRESS,
    OPTION_LOCAL_PORT,
    OPTION_REMOTE_PORT,
    OPTION_PRINT_FILTER,
};

static struct option longopts[] = {
    { "help",		no_argument,	   NULL, OPTION_HELP		},
    { "local-address",	required_argument, NULL, OPTION_LOCAL_ADDRESS 	},
    { "remote-address",	required_argument, NULL, OPTION_REMOTE_ADDRESS	},
    { "local-port",	required_argument, NULL, OPTION_LOCAL_PORT 	},
    { "remote-port",	required_argument, NULL, OPTION_REMOTE_PORT	},
    { "print-filter",   no_argument,	   NULL, OPTION_PRINT_FILTER	},
};

/*----------------------------------------------------------------------
 * Prints usage information to 'out'.
 *----------------------------------------------------------------------*/
static void usage(FILE *out) {
    fprintf(out, 
"Filters tcpinfo packets by the given rules and writes them to standard\n"
"output.\n\n"
"Usage: %s [OPTIONS]\n"
"       %s [OPTIONS] INPUT-FILE\n"
"\n"
"Options:\n"
"  --local-address=ADDRMASK  only output packets with a local address\n"
"                            matching the given mask\n"
"  --local-port=PORTRANGE    only output packets with a local port in the\n"
"                            given range (inclusive)\n"
"  --remote-address=ADDRMASK only output packets with a remote address\n"
"                            matching the given mask\n"
"  --remote-port=PORTRANGE   only output packets with a remote port in the\n"
"                            given range (inclusive)\n"
"  --print-filter            print the generated filter to standard error\n"
"                            output\n"
"  --help                    display this help\n"
"\n"
"Address Mask Syntax\n"
"  IP/[BitCount]\n"
"\n"
"  Examples: 127.0.0.1\n"
"            192.168.0.0/16\n"
"\n"
"Port Range Syntax\n"
"  SinglePort\n"
"  :MaxPort\n"
"  MinPort:\n"
"  MinPort:MaxPort\n"
"\n"
"  Examples: 1000      -> only port 1000\n"
"            :1000     -> port 0 to 1000, inclusive\n"
"            1000:     -> port 1000 to 65535, inclusive\n"
"            1000:2000 -> port 1000 to 2000, inclusive\n", 
progname, progname);
}

/*----------------------------------------------------------------------
 * The signal handler (handles all signals) 
 *---------------------------------------------------------------------*/
static void sighandler(int signum) {
    switch (signum) {

	/* We quit on SIGINT (Control-C), SIGTERM and SIGHUP */
	case SIGINT:
	case SIGTERM:
	case SIGHUP:
	    quit = 1;
	    retval = EXIT_FAILURE;
	    break;

	/* We shouldn't get any other signals here; warn if we do */
	default:
	    fprintf(stderr, "%s: caught unexpected signal: %i\n", 
		    progname, signum);
	    break;
    }
}

/*----------------------------------------------------------------------
 * Parses a port range string and fills the two values into *minport 
 * and *maxport. Returns 0 on success, -1 on failure.
 *
 * Range syntax by example:
 *
 * Range		Min Port	Max Port
 * 100			100		100
 * 100:1000		100		1000
 * 100:			100		65535
 * :100			0		100
 * :			0		65535
 *----------------------------------------------------------------------*/
static int parse_port(const char *range, uint16_t *minport, 
	uint16_t *maxport) {
    const char *sep;
    char *endptr;
    long minport_long, maxport_long;
    
    assert(range);
    assert(minport);
    assert(maxport);

    /* Look for a separator */
    sep = strchr(range, ':');
    if (sep) {
	/* There is a separator. Three cases:
	 * x:y	-> x:y
	 * :y	-> MIN_PORT:x
	 * x:	-> x:MAX_PORT
	 */

	if (sep == range) {
	    minport_long = MIN_PORT;
	}
	else {
	    minport_long = strtol(range, &endptr, 10);
	    if (endptr != sep) return -1;
	}

	if (*(sep+1)) {
	    maxport_long = strtol(sep + 1, &endptr, 10);
	    if (*endptr) return -1;
	}
	else {
	    maxport_long = MAX_PORT;
	}
    }
    else {
	/* There was no separator, just one number */
	minport_long = maxport_long = strtol(range, &endptr, 10);
	if (*endptr) return -1;
    }

    /* Range check the port numbers */
    if (minport_long < MIN_PORT || minport_long > MAX_PORT
	|| maxport_long < MIN_PORT || maxport_long > MAX_PORT)
	return -1;
    
    /* Check whether the range makes sense */
    if (minport_long > maxport_long) return -1;

    *minport = minport_long;
    *maxport = maxport_long;

    return 0;
}

/*----------------------------------------------------------------------
 * Parses a network address/mask pair and converts it to suitable 32-bit
 * uints. Returns 0 in case of success, -1 otherwise.
 *
 * Network/address mask syntax by example:
 *
 * Network/address mask		Address		Mask
 * 127.0.0.1			127.0.0.1	255.255.255.255
 * 127.0.0.1/32			127.0.0.1	255.255.255.255
 * 127.0.0.1/24			127.0.0.1	255.255.255.0
 * 127.0.0.1/9			127.0.0.1	255.128.0.0
 *----------------------------------------------------------------------*/
static int parse_addr_and_mask(const char *s, uint32_t *addr,
	uint32_t *mask) {
    struct in_addr tmp_addr;
    uint32_t tmp_mask;
    const char *sep, *addr_str;
    char buf[50];
    
    assert(s);
    assert(addr);
    assert(mask);

    /* Find the separator '/' */
    sep = strchr(s, '/');
    if (sep) {
	/* We have a separator */
	size_t len;
	long mask_len;
	char *endptr;

	len = sep - s;
	if (len > sizeof(buf) - 1) len = sizeof(buf) - 1;
	memcpy(buf, s, len);
	buf[len] = 0;

	addr_str = buf;

	/* Convert the mask size */
	mask_len = strtol(sep + 1, &endptr, 10);
	if (*endptr) return -1;

	/* Range-check the mask size */
	if (mask_len < 0 || mask_len > 32) return -1;
	
	/* Convert the mask size to an actual mask */
	tmp_mask = 0;
	while (mask_len--) tmp_mask = (tmp_mask >> 1) | (1 << 31);
    }
    else {
	/* No separator */
	addr_str = s;
	tmp_mask = (uint32_t) -1;
    }

    /* Convert the address */
    if (inet_pton(AF_INET, addr_str, &tmp_addr) <= 0) return -1;

    /* Copy it to the supplied buffers */
    *addr = tmp_addr.s_addr;
    *mask = htonl(tmp_mask);
    return 0;
}

/*----------------------------------------------------------------------
 * Checks whether addr matches the given filter address filter_addr and 
 * mask filter_addr_mask. Returns 1 if the addresses match, 0 if they
 * don't.
 *----------------------------------------------------------------------*/
static int filter_check_address(uint32_t addr, uint32_t filter_addr,
	uint32_t filter_addr_mask) {
    return (addr & filter_addr_mask) == (filter_addr & filter_addr_mask);
}

/*----------------------------------------------------------------------
 * Checks whether packet matches the given filter or not. Returns 1 in
 * case of a match, 0 otherwise.
 *----------------------------------------------------------------------*/
static int filter_check(const struct tcpinfo_packet *packet,
		       const struct filter *filter) {
    uint16_t local_port, remote_port;
    
    /* Check whether the addresses pass */
    if (!filter_check_address(packet->local_addr, filter->local_addr,
	    filter->local_addr_mask)) return 0;
    if (!filter_check_address(packet->remote_addr, filter->remote_addr,
	    filter->remote_addr_mask)) return 0;

    /* Convert the packet ports to host order */
    /* Check whether the ports pass */
    local_port = ntohs(packet->local_port);
    if (local_port < filter->min_local_port 
	    || local_port > filter->max_local_port) return 0;
    remote_port = ntohs(packet->remote_port);
    if (remote_port < filter->min_remote_port 
	    || remote_port > filter->max_remote_port) return 0;

    return 1;
}

/*----------------------------------------------------------------------
 * Prints filter to out in human readable format. Used for debugging and 
 * to check whether your filter rules do what they should.
 *----------------------------------------------------------------------*/
static void filter_print(FILE *out, const struct filter *filter) {
    char local_addr_str[50], remote_addr_str[50],
	 local_addr_mask_str[50], remote_addr_mask_str[50];

    /* Convert the IP addresses to dotted-number format */
    inet_ntop(AF_INET, &filter->local_addr, local_addr_str,
	    sizeof(local_addr_str));
    inet_ntop(AF_INET, &filter->remote_addr, remote_addr_str,
	    sizeof(remote_addr_str));
    inet_ntop(AF_INET, &filter->local_addr_mask, local_addr_mask_str,
	    sizeof(local_addr_mask_str));
    inet_ntop(AF_INET, &filter->remote_addr_mask, remote_addr_mask_str,
	    sizeof(remote_addr_mask_str));

    /* Print the filter to stdout */
    fprintf(out, "Local address:       %s\n", local_addr_str);
    fprintf(out, "Local address mask:  %s\n", local_addr_mask_str);
    fprintf(out, "Local port range:    %i:%i\n", 
	    filter->min_local_port, filter->max_local_port);
    fprintf(out, "Remote address:      %s\n", remote_addr_str);
    fprintf(out, "Remote address mask: %s\n", remote_addr_mask_str);
    fprintf(out, "Remote port range:   %i:%i\n", 
	    filter->min_remote_port, filter->max_remote_port);
}
 
/*----------------------------------------------------------------------
 * The main function.
 *----------------------------------------------------------------------*/
int main(int argc, char **argv) {
    int in_fd, out_fd, close_in_fd, close_out_fd, getopt_done;
    const char *filename;
    struct filter filter;
    int print_filter = 0;

    /* Set the program name */
    progname = argv[0];

    /* Set up the default (pass-all) filter */
    filter.local_addr = 0;
    filter.local_addr_mask = 0;
    filter.min_local_port = MIN_PORT;
    filter.max_local_port = MAX_PORT;

    filter.remote_addr = 0;
    filter.remote_addr_mask = 0;
    filter.min_remote_port = MIN_PORT;
    filter.max_remote_port = MAX_PORT;

    /* Parse the arguments */
    getopt_done = 0;
    while (!getopt_done) {
	int ch;
	
	ch = getopt_long(argc, argv, "", longopts, NULL);
	switch (ch) {
	    case -1:
		getopt_done = 1;
		break;
		
	    case '?':
		/* error */
		fprintf(stderr, "%s: invalid command line option\n",
			progname);
		return EXIT_FAILURE;

	    case OPTION_HELP:
		usage(stdout);
		return EXIT_SUCCESS;
		
	    case OPTION_LOCAL_ADDRESS:
		if (parse_addr_and_mask(optarg, &filter.local_addr,
			    &filter.local_addr_mask) == -1) {
		    fprintf(stderr, "%s: invalid address mask %s; "
			    "try --help\n", progname, optarg);
		    return EXIT_FAILURE;
		}
		break;

	    case OPTION_LOCAL_PORT:
		if (parse_port(optarg, &filter.min_local_port,
			&filter.max_local_port) == -1) {
		    fprintf(stderr, "%s: invalid port range %s; try --help\n", 
			    progname, optarg);
		    return EXIT_FAILURE;
		}
		break;
		
	    case OPTION_REMOTE_ADDRESS:
		if (parse_addr_and_mask(optarg, &filter.remote_addr,
			    &filter.remote_addr_mask) == -1) {
		    fprintf(stderr, "%s: invalid address mask %s; "
			    "try --help\n", progname, optarg);
		    return EXIT_FAILURE;
		}
		break;

	    case OPTION_REMOTE_PORT:
		if (parse_port(optarg, &filter.min_remote_port,
			&filter.max_remote_port) == -1) {
		    fprintf(stderr, "%s: invalid port range %s; try --help\n", 
			    progname, optarg);
		    return EXIT_FAILURE;
		}
		break;

	    case OPTION_PRINT_FILTER:
		print_filter = 1;
		break;

	    default:
		fprintf(stderr, "%s: unhandled option %i (bug in program)\n", 
			progname, ch);
		return EXIT_FAILURE;
	}
    }

    /* Print the filter if requested */
    if (print_filter) filter_print(stderr, &filter);

    /* Check the file arguments */
    if (argc - optind == 0) {
	/* Read from standard input */
	in_fd = 0; 		/* 0 is stdin */
	close_in_fd = 0;	/* Do not close stdin on exit */
	filename = "(stdin)";
    }
    else if (argc - optind == 1) {
	/* A file name was given on the command line */

        filename = argv[optind];

	/* Open the file */
	in_fd = open(filename, O_RDONLY);
	if (in_fd == -1) {
	    fprintf(stderr, "%s: cannot open %s: %s\n", 
		    progname, filename, strerror(errno));
	    return EXIT_FAILURE;
	}

	/* We opened the file, so we close it in the end */
	close_in_fd = 1;
    }
    else {
	/* Multiple file names on the command line */
	fprintf(stderr, "%s: invalid number of file names\n",
		progname);
	return EXIT_FAILURE;
    }

    /* For the moment we always send output to stdout, but this can be
     * extended to writing to files easily; just look at the in_fd logic */
    out_fd = 1;
    close_out_fd = 0;

    /* Install an interrupting signal handler for SIGINT (Control-C),
     * SIGTERM and SIGHUP */
    signal(SIGINT, sighandler);
    siginterrupt(SIGINT, 1);
    signal(SIGTERM, sighandler);
    siginterrupt(SIGTERM, 1);
    signal(SIGHUP, sighandler);
    siginterrupt(SIGHUP, 1);

    /* Read until quit is set (i.e. until we're interrupted or reached
     * EOF) */
    while (!quit) {
	struct tcpinfo_packet packet;
	size_t remaining_bytes = sizeof(packet);

	/* Read until the packet structure is full */
	while (!quit && remaining_bytes) {
	    ssize_t read_size;

	    read_size = read(in_fd, ((char*) &packet) 
		    + sizeof(packet) - remaining_bytes, 
		    remaining_bytes);
	    if (read_size == -1) {
		if (errno != EINTR) {
		    fprintf(stderr, "%s: cannot read from %s: %s\n",
			    progname, filename, strerror(errno));
		    retval = EXIT_FAILURE;
		    quit = 1;
		}
	    }
	    else if (read_size == 0) {
		/* EOF */
		quit = 1;
	    }
	    else {
		/* We were able to read something */
		remaining_bytes -= read_size;
	    }
	}

	/* Only proceed if the packet was filled (it won't be filled after 
	 * an interruption) */
	if (!remaining_bytes) {
	    /* Check the magic number and the size */
	    if (packet.magic != TCPINFO_MAGIC_NUMBER) {
		fprintf(stderr, "%s: %s: wrong magic number (got %u, "
			"expected %lu)\n", progname, filename, 
			packet.magic, TCPINFO_MAGIC_NUMBER);
		retval = EXIT_FAILURE;
		quit = 1;
	    }

	    if (packet.size != sizeof(packet)) {
		fprintf(stderr, "%s: %s: wrong packet size (got %u, "
			"expected %u)\n", progname, filename,
			packet.size, sizeof(packet));
		retval = EXIT_FAILURE;
		quit = 1;
	    }

	    if (!quit && filter_check(&packet, &filter)) {
		size_t remaining_bytes = sizeof(packet);

		/* Always write whole packets */
		while (remaining_bytes) {
		    ssize_t ret;
		    ret = write(out_fd, &packet, sizeof(packet));
		    if (ret == -1) {
			if (errno != EINTR) {
			    fprintf(stderr, "%s: cannot write output: %s\n", 
				    progname, strerror(errno));
			    retval = EXIT_FAILURE;
			    quit = 1;
			}
		    }
		    else
			remaining_bytes -= ret;
		}
	    }
	}
    }
    
    if (close_in_fd) close(in_fd);
    if (close_out_fd) close(out_fd);

    return retval;
}
