/* $Id: tiana.c 12 2006-09-23 23:28:08Z aaron $ - vim:sw=4 tw=72
 *
 * tidecode reads a sequence of struct tcpinfo_packet from a file or 
 * standard input and prints it to stdout in a human-readable fashion.
 *
 * Author:	Aaron Isotton <aaron@isotton.com>
 */

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <getopt.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "../include/tcpinfo.h"

/*----------------------------------------------------------------------
 * Constants
 *----------------------------------------------------------------------*/
const double DEFAULT_INTERVAL = 1.0;

/*----------------------------------------------------------------------
 * Types
 *----------------------------------------------------------------------*/
struct analyzer {
    int fixed;
    uint32_t local_addr;
    uint16_t local_port;
    uint32_t remote_addr;
    uint32_t remote_port;
    double interval;
    double ana_timestamp, last_timestamp;
    uint32_t ana_seq, last_seq;
};

/*----------------------------------------------------------------------
 * Globals
 *----------------------------------------------------------------------*/
static volatile int quit = 0;			/* The quit flag */
static volatile int retval = EXIT_SUCCESS;	/* The return value of main() */
static volatile char *progname;

/*----------------------------------------------------------------------
 * Externs
 *----------------------------------------------------------------------*/
extern int optind;
extern char *optarg;

/*----------------------------------------------------------------------
 * Command line options. Extend as you wish
 *----------------------------------------------------------------------*/
enum {
    OPTION_HELP = 1,
    OPTION_INTERVAL
};

static struct option longopts[] = {
    { "help",		no_argument,		NULL, OPTION_HELP	},
    { "interval",	required_argument,	NULL, OPTION_INTERVAL	},
};

/*----------------------------------------------------------------------
 * Prints usage information to 'out'
 *----------------------------------------------------------------------*/
static void usage(FILE *out) {
    fprintf(out,
"Usage: %s [OPTIONS]\n"
"       %s [OPTIONS] INPUT-FILE\n"
"\n"
"Options:\n"
"  --interval=INTERVAL  Set the analyzer interval to INTERVAL seconds\n"
"                       (default %.2f)\n"
"  --help               Display this help\n",
	progname, progname, DEFAULT_INTERVAL);
}

/*----------------------------------------------------------------------
 * The signal handler (handles all signals) 
 *---------------------------------------------------------------------*/
static void sighandler(int signum) {
    switch (signum) {

	/* We quit on SIGINT (Control-C), SIGTERM and SIGHUP */
	case SIGINT:
	case SIGTERM:
	case SIGHUP:
	    quit = 1;
	    retval = EXIT_FAILURE;
	    break;

	/* We shouldn't get any other signals here; warn if we do */
	default:
	    fprintf(stderr, "%s: caught unexpected signal: %i\n", 
		    progname, signum);
	    break;
    }
}


/*----------------------------------------------------------------------
 * Analyzes and prints a tcpinfo_packet to stdout 
 *----------------------------------------------------------------------*/
static void analyze_packet(struct analyzer *analyzer,
	const struct tcpinfo_packet *packet) {
    double timestamp, delta;

    /* Skip all received packets */
    if (packet->direction == TCPINFO_PACKET_DIRECTION_RCV)
	return;

    if (!analyzer->fixed) {
	char local_addr_str[50], remote_addr_str[50];

	analyzer->fixed = 1;
	analyzer->local_addr = packet->local_addr;
	analyzer->local_port = packet->local_port;
	analyzer->remote_addr = packet->remote_addr;
	analyzer->remote_port = packet->remote_port;
	analyzer->ana_seq = analyzer->last_seq = packet->seq;
	analyzer->ana_timestamp = analyzer->last_timestamp  
	    = packet->cycles / (packet->cpu_khz * 1000.);

	/* Convert the IP addres to dotted-number format */
	inet_ntop(AF_INET, &analyzer->local_addr, local_addr_str,
		sizeof(local_addr_str));
	inet_ntop(AF_INET, &analyzer->remote_addr, remote_addr_str,
		sizeof(remote_addr_str));

	printf("# analyzing packets with local address %s:%hu\n# and "
	       "remote address %s:%hu\n# ignoring all other packets\n", 
	       local_addr_str, analyzer->local_port, 
	       remote_addr_str, analyzer->remote_port);
    }

    /* Skip all packets not matching our analyzer */
    if (analyzer->local_addr != packet->local_addr
	|| analyzer->local_port != packet->local_port
	|| analyzer->remote_addr != packet->remote_addr
	|| analyzer->remote_port != packet->remote_port) return;

    timestamp = packet->cycles / (packet->cpu_khz * 1000.);
    delta = timestamp - analyzer->ana_timestamp;

    if (delta >= analyzer->interval) {
	double interp_factor, throughput;
	uint32_t interp_seq;

	interp_factor = (analyzer->ana_timestamp + analyzer->interval 
		- analyzer->last_timestamp) 
	    / (timestamp - analyzer->last_timestamp);
	interp_seq = analyzer->last_seq 
	    + (packet->seq - analyzer->last_seq) * interp_factor;
	throughput = (interp_seq - analyzer->ana_seq) 
	    / analyzer->interval;

	analyzer->ana_timestamp += analyzer->interval;
	analyzer->ana_seq = interp_seq;

	printf("%16.8f %16.2f\n", analyzer->ana_timestamp, throughput);
    }

    analyzer->last_timestamp = timestamp;
    analyzer->last_seq = packet->seq;
}

/*----------------------------------------------------------------------
 * The main function.
 *----------------------------------------------------------------------*/
int main(int argc, char **argv) {
    int fd, close_fd, getopt_done;
    const char *filename;
    struct analyzer analyzer;

    /* Set the program name */
    progname = argv[0];

    /* Set a default interval */
    analyzer.interval = DEFAULT_INTERVAL;

    /* Parse the arguments */
    getopt_done = 0;
    while (!getopt_done) {
	int ch;

	ch = getopt_long(argc, argv, "", longopts, NULL);
	switch (ch) {
	    case -1:
		getopt_done = 1;
		break;

	    case '?':
		/* error */
		fprintf(stderr, "%s: invalid command line option\n", progname);
		return EXIT_FAILURE;

	    case OPTION_HELP:
		usage(stdout);
		return EXIT_SUCCESS;

	    case OPTION_INTERVAL: {
		char *endptr;
		double tmp;

		tmp = strtod(optarg, &endptr);
		if (*endptr || tmp <= 0) {
		    fprintf(stderr, "%s: invalid interval %s; try --help\n",
			    progname, optarg);
		    return EXIT_FAILURE;
		}
		analyzer.interval = tmp;
		break;}

	    default:
		fprintf(stderr, "%s: unhandled option %i (bug in program)\n",
			progname, ch);
		return EXIT_FAILURE;
	}
    }

    /* Check the arguments */
    if (argc - optind == 0) {
	filename = "(stdin)";
	fd = 0;
	close_fd = 0;
    }
    else if (argc - optind == 1) {
	filename = argv[optind];

	/* Open the device */
	fd = open(filename, O_RDONLY);
	if (fd == -1) {
	    fprintf(stderr, "%s: cannot open %s: %s\n", 
		    progname, filename, strerror(errno));
	    return EXIT_FAILURE;
	}
	close_fd = 1;
    }
    else {
	fprintf(stderr, "%s: invalid number of command line argumets; "
		"try --help", progname);
	return EXIT_FAILURE;
    }

    /* Install an interrupting signal handler for SIGINT (Control-C), 
     * SIGTERM and SIGHUP */
    signal(SIGINT, sighandler);
    siginterrupt(SIGINT, 1);
    signal(SIGTERM, sighandler);
    siginterrupt(SIGTERM, 1);
    signal(SIGHUP, sighandler);
    siginterrupt(SIGHUP, 1);

    /* Set up the analyzer structure */
    analyzer.fixed = 0;

    /* Read until quit is set (i.e. until we're interrupted) */
    while (!quit) {
	struct tcpinfo_packet packet;
	size_t remaining_bytes = sizeof(packet);

	/* Read until the packet structure is full */
	while (!quit && remaining_bytes) {
	    ssize_t read_size;

	    read_size = read(fd, ((char*) &packet) 
		    + sizeof(packet) - remaining_bytes, 
		    remaining_bytes);
	    if (read_size == -1) {
		if (errno != EINTR) {
		    fprintf(stderr, "%s: cannot read from %s: %s\n",
			    progname, filename, strerror(errno));
		    retval = EXIT_FAILURE;
		    quit = 1;
		}
	    }
	    else if (read_size == 0) {
		/* EOF */
		quit = 1;
	    }
	    else {
		/* We were able to read something */
		remaining_bytes -= read_size;
	    }
	}

	/* Only proceed if the packet was filled (it won't be filled after 
	 * an interruption) */
	if (!remaining_bytes) {
	    /* Check the magic number and the size */
	    if (packet.magic != TCPINFO_MAGIC_NUMBER) {
		fprintf(stderr, "%s: %s: wrong magic number (got %u, "
			"expected %lu)\n", progname, filename, 
			packet.magic, TCPINFO_MAGIC_NUMBER);
		retval = EXIT_FAILURE;
		quit = 1;
	    }

	    if (packet.size != sizeof(packet)) {
		fprintf(stderr, "%s: %s: wrong packet size (got %u, "
			"expected %u)\n", progname, filename,
			packet.size, sizeof(packet));
		retval = EXIT_FAILURE;
		quit = 1;
	    }

	    if (!quit) {
		analyze_packet(&analyzer, &packet);
	    }

	}
    }
    
    if (close_fd) close(fd);

    return retval;
}
