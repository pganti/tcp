/* $Id: tidecode.c 1 2006-08-27 15:27:37Z aaron $ - vim:sw=4 tw=72
 *
 * tidecode reads a sequence of struct tcpinfo_packet from a file or 
 * standard input and prints it to stdout in a human-readable fashion.
 *
 * Author:	Aaron Isotton <aaron@isotton.com>
 */

#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <getopt.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "../include/tcpinfo.h"

/*----------------------------------------------------------------------
 * Constants
 *----------------------------------------------------------------------*/
#define MAX_CONNECTIONS 20		/* The maximum number of 
					   connections which can be 
					   analyzed */
#define MAX_WINDOW_SIZE 1000		/* The maximum number of packets
					   stored per connection for
					   throughput calculations */
#define DEFAULT_SMOOTH_WIDTH .5
/*----------------------------------------------------------------------
 * Types
 *----------------------------------------------------------------------*/
struct seq_in_time {
    double timestamp, seq;
};

struct connection {
    int used;
    enum tcpinfo_packet_direction direction;
    uint32_t local_addr;
    uint16_t local_port;
    uint32_t remote_addr;
    uint32_t remote_port;
    uint32_t last_seq;
    double last_timestamp;

    struct seq_in_time seqs[MAX_WINDOW_SIZE];
    size_t window_size;
};

/*----------------------------------------------------------------------
 * Globals
 *----------------------------------------------------------------------*/
static volatile int quit = 0;			/* The quit flag */
static volatile int retval = EXIT_SUCCESS;	/* The return value of main() */
static volatile char *progname;

/*----------------------------------------------------------------------
 * Externs
 *----------------------------------------------------------------------*/
extern int optind;
extern char *optarg;

/*----------------------------------------------------------------------
 * Command line options. Extend as you wish.
 *----------------------------------------------------------------------*/
enum {
    OPTION_HELP = 1,
    OPTION_SMOOTH_WIDTH,
};

static struct option longopts[] = {
    { "help",		no_argument,	   NULL, OPTION_HELP		},
    { "smooth-width",	required_argument, NULL, OPTION_SMOOTH_WIDTH 	},
};

/*----------------------------------------------------------------------
 * Prints usage information to 'out'.
 *----------------------------------------------------------------------*/
static void usage(FILE *out) {
    fprintf(out, 
"Usage: %s [OPTIONS]\n"
"       %s [OPTIONS] INPUT-FILE\n"
"\n"
"Options:\n"
"  --smooth-width=W  Use a custom smooth width of W seconds (default: %.2f)\n"
"  --help            Display this help\n", 
	progname, progname, DEFAULT_SMOOTH_WIDTH);
}


/*----------------------------------------------------------------------
 * The signal handler (handles all signals) 
 *---------------------------------------------------------------------*/
static void sighandler(int signum) {
    switch (signum) {

	/* We quit on SIGINT (Control-C), SIGTERM and SIGHUP */
	case SIGINT:
	case SIGTERM:
	case SIGHUP:
	    quit = 1;
	    retval = EXIT_FAILURE;
	    break;

	/* We shouldn't get any other signals here; warn if we do */
	default:
	    fprintf(stderr, "%s: caught unexpected signal: %i\n", 
		    progname, signum);
	    break;
    }
}


/*----------------------------------------------------------------------
 * Prints a tcpinfo_packet to stdout 
 *----------------------------------------------------------------------*/
static void print_packet(const struct tcpinfo_packet *packet,
	struct connection *connections, size_t n_connections,
	double smooth_width) {
    size_t i;
    char local_addr_str[50], remote_addr_str[50];
    double timestamp, throughput, smoothed_throughput;
    struct connection *connection;

    /* Convert the IP addresses to dotted-number format */
    inet_ntop(AF_INET, &packet->local_addr, local_addr_str,
	    sizeof(local_addr_str));
    inet_ntop(AF_INET, &packet->remote_addr, remote_addr_str,
	    sizeof(remote_addr_str));

    /* Calculate the timestamp */
    timestamp = packet->cycles / (packet->cpu_khz * 1000.);

    /* Find out whether we are already monitoring this connection */
    connection = NULL;
    for (i = 0; i < n_connections && connections[i].used; ++i) {
	struct connection *c = connections + i;
	if (   packet->direction   == c->direction
	    && packet->local_addr  == c->local_addr
	    && packet->local_port  == c->local_port
	    && packet->remote_addr == c->remote_addr
	    && packet->remote_port == c->remote_port) {
		connection = c;
		break;
	}
    }

    /* Initialize a new connection object if we found none and we still
     * have space */
    if (!connection) {
	if (i < n_connections) {
	    connection = connections + i;
	    connection->used = 1;
	    connection->direction = packet->direction;
	    connection->local_addr = packet->local_addr;
	    connection->local_port = packet->local_port;
	    connection->remote_addr = packet->remote_addr;
	    connection->remote_port = packet->remote_port;
	    connection->last_seq = packet->seq;
	    connection->last_timestamp = timestamp;
	    connection->window_size = 0;
	}
	else {
	    /* We have no free connection objects left */
	    fprintf(stderr, "%s: more than %u connections; try increasing "
		    "MAX_CONNECTIONS\n", progname, n_connections);
	}
    }

    if (connection) {
	uint32_t start_seq;
	double start_timestamp, time_delta;

	if (timestamp == connection->last_timestamp)
	    throughput = 0;
	else
	    throughput = (packet->seq - connection->last_seq) 
		/ (timestamp - connection->last_timestamp);

	connection->last_seq = packet->seq;
	connection->last_timestamp = timestamp;

	memmove(connection->seqs + 1, connection->seqs,
		sizeof(struct seq_in_time) * (MAX_WINDOW_SIZE - 1));
	connection->seqs[0].timestamp = timestamp;
	connection->seqs[0].seq = packet->seq;
	if (connection->window_size < MAX_WINDOW_SIZE)
	    ++connection->window_size;

	for (i = 0; i < connection->window_size 
		&& connection->seqs[i].timestamp 
		+ smooth_width >= timestamp; ++i);

	if (i) {
	    start_seq = connection->seqs[i-1].seq;
	    start_timestamp = connection->seqs[i-1].timestamp;

	    time_delta = timestamp - start_timestamp;

	    if (time_delta)
		smoothed_throughput = (packet->seq - start_seq) / time_delta;
	    else
		smoothed_throughput = 0;
	}
	else
	    smoothed_throughput = 0;
    }
    else {
	throughput = 0;
	smoothed_throughput = 0;
    }

    printf("%14.6f %3s %15s %10hu %15s %11hu %10u %10u %8u %13u %12u %7u "
	    "%12.6f %20.6f %10.0f %19.0f\n", 
	    timestamp,
	    packet->direction == TCPINFO_PACKET_DIRECTION_SND ? "snd" : "rcv",
	    local_addr_str,
	    packet->local_port,
	    remote_addr_str,
	    packet->remote_port,
	    packet->seq,
	    packet->ack_seq,
	    packet->snd_cwnd, 
	    packet->snd_cwnd_used,
	    packet->snd_cwnd_cnt, 
	    packet->rcv_wnd,
	    packet->rtt_smoothed / 256.,
	    packet->rtt_medium_deviation / 256.,
	    throughput,
	    smoothed_throughput);
}

/*----------------------------------------------------------------------
 * The main function.
 *----------------------------------------------------------------------*/
int main(int argc, char **argv) {
    int fd, close_fd, getopt_done;
    const char *filename;
    struct connection connections[MAX_CONNECTIONS];
    size_t i;
    double smooth_width = DEFAULT_SMOOTH_WIDTH;

    /* Set the program name */
    progname = argv[0];

    /* Parse the arguments */
    getopt_done = 0;
    while (!getopt_done) {
	int ch;
	
	ch = getopt_long(argc, argv, "", longopts, NULL);
	switch (ch) {
	    case -1:
		getopt_done = 1;
		break;
		
	    case '?':
		/* error */
		fprintf(stderr, "%s: invalid command line option\n",
			progname);
		return EXIT_FAILURE;

	    case OPTION_HELP:
		usage(stdout);
		return EXIT_SUCCESS;
		
	    case OPTION_SMOOTH_WIDTH: {
		char *endptr;

		smooth_width = strtod(optarg, &endptr);
		if (*endptr) {
		    fprintf(stderr, "%s: invalid smooth width %s; "
			    "try --help\n", progname, optarg);
		    return EXIT_FAILURE;
		}
		break;}

	    default:
		fprintf(stderr, "%s: unhandled option %i (bug in program)\n", 
			progname, ch);
		return EXIT_FAILURE;
	}
    }


    /* Check the arguments */
    if (argc - optind == 0) {
	filename = "(stdin)";
	fd = 0;
	close_fd = 0;
    }
    else if (argc - optind == 1) {
	filename = argv[optind];

	/* Open the device */
	fd = open(filename, O_RDONLY);
	if (fd == -1) {
	    fprintf(stderr, "%s: cannot open %s: %s\n", 
		    progname, filename, strerror(errno));
	    return EXIT_FAILURE;
	}
	close_fd = 1;
    }
    else {
	usage(stderr);
	return EXIT_FAILURE;
    }

    /* Install an interrupting signal handler for SIGINT (Control-C), 
     * SIGTERM and SIGHUP */
    signal(SIGINT, sighandler);
    siginterrupt(SIGINT, 1);
    signal(SIGTERM, sighandler);
    siginterrupt(SIGTERM, 1);
    signal(SIGHUP, sighandler);
    siginterrupt(SIGHUP, 1);

    /* Initialize the connection objects */
    for (i = 0; i < MAX_CONNECTIONS; ++i)
	connections->used = 0;

    /* Print the title row; commented out so we can use the output
     * directly in gnuplot */
    printf("#         time dir   local_address local_port  remote_address "
	   "remote_port        seq    ack_seq snd_cwnd snd_cwnd_used "
	   "snd_cwnd_cnt rcv_wnd rtt_smoothed rtt_medium_deviation "
	   "throughput smoothed_throughput\n");
    
    /* Read until quit is set (i.e. until we're interrupted) */
    while (!quit) {
	struct tcpinfo_packet packet;
	size_t remaining_bytes = sizeof(packet);

	/* Read until the packet structure is full */
	while (!quit && remaining_bytes) {
	    ssize_t read_size;

	    read_size = read(fd, ((char*) &packet) 
		    + sizeof(packet) - remaining_bytes, 
		    remaining_bytes);
	    if (read_size == -1) {
		if (errno != EINTR) {
		    fprintf(stderr, "%s: cannot read from %s: %s\n",
			    progname, filename, strerror(errno));
		    retval = EXIT_FAILURE;
		    quit = 1;
		}
	    }
	    else if (read_size == 0) {
		/* EOF */
		quit = 1;
	    }
	    else {
		/* We were able to read something */
		remaining_bytes -= read_size;
	    }
	}

	/* Only proceed if the packet was filled (it won't be filled after 
	 * an interruption) */
	if (!remaining_bytes) {
	    /* Check the magic number and the size */
	    if (packet.magic != TCPINFO_MAGIC_NUMBER) {
		fprintf(stderr, "%s: %s: wrong magic number (got %u, "
			"expected %lu)\n", progname, filename, 
			packet.magic, TCPINFO_MAGIC_NUMBER);
		retval = EXIT_FAILURE;
		quit = 1;
	    }

	    if (packet.size != sizeof(packet)) {
		fprintf(stderr, "%s: %s: wrong packet size (got %u, "
			"expected %u)\n", progname, filename,
			packet.size, sizeof(packet));
		retval = EXIT_FAILURE;
		quit = 1;
	    }

	    if (!quit) print_packet(&packet, connections, MAX_CONNECTIONS,
		    smooth_width);

	}
    }
    
    if (close_fd) close(fd);

    return retval;
}
