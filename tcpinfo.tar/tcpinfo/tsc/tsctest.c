/* $Id: tsctest.c 4 2006-08-27 15:44:00Z aaron $ - vim:sw=4
 *
 * This program sleeps for about 30 seconds, measures the time using the TSC
 * and gettimeofday() and compares the results.
 *
 * Author:	Aaron Isotton <aaron@isotton.com>
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <asm/msr.h>
#include "cpuinfo.h"

#define WAITTIME 30

int main() {
    unsigned long long tsc_start, tsc_end;
    struct timeval tv_start, tv_end;
    double delta_gettimeofday, delta_tsc, cpu_frequency;

    if (get_cpu_frequency(&cpu_frequency) == -1)
	return EXIT_FAILURE;

    /* start time */
    fprintf(stderr, "*** Please make sure that your system is idle ***\n\n");
    fprintf(stderr, "* Measuring start time\n");
    gettimeofday(&tv_start, NULL);
    rdtscll(tsc_start);

    /* wait */
    fprintf(stderr, "* Waiting for %us.\n", WAITTIME);
    sleep(WAITTIME);

    /* end time */
    fprintf(stderr, "* Measuring end time.\n");
    gettimeofday(&tv_end, NULL);
    rdtscll(tsc_end);

    delta_gettimeofday = (tv_end.tv_sec - tv_start.tv_sec)
	+ (1. * tv_end.tv_usec - tv_start.tv_usec) / 1000000.;

    delta_tsc = 1. * (tsc_end - tsc_start) / cpu_frequency;

    fprintf(stderr, "\n");
    printf("Elapsed time (gettimeofday): %2.4f\n", delta_gettimeofday);
    printf("Elapsed time (TSC):          %2.4f (factor: %.8f)\n", 
	    delta_tsc, delta_tsc / delta_gettimeofday);

    return EXIT_SUCCESS;
}
