#ifndef TSC_CPUINFO_H
#define TSC_CPUINFO_H

int get_cpu_frequency(double *frequency);

#endif
