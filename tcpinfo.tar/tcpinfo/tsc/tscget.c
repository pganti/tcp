/* $Id: tscget.c 4 2006-08-27 15:44:00Z aaron $ - vim:sw=4
 *
 * Prints the current value of the TSC divided by the CPU frequency.
 *
 * Author:	Aaron Isotton <aaron@isotton.com>
 */

#include <stdio.h>
#include <stdlib.h>
#include <asm/msr.h>
#include "cpuinfo.h"


int main() {
    double cpu_frequency;
    unsigned long long tsc;

    if (get_cpu_frequency(&cpu_frequency) == -1)
	return EXIT_FAILURE;

    rdtscll(tsc);
    printf("%12.6f\n", tsc / cpu_frequency);

    return EXIT_SUCCESS;
}
