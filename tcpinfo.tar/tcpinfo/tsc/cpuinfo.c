/* $Id: cpuinfo.c 1 2006-08-27 15:27:37Z aaron $ - vim:sw=4
 *
 * Retrieves the CPU frequency from /proc/cpuinfo.
 *
 * Author:	Aaron Isotton <aaron@isotton.com>
 */

#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CPUINFO "/proc/cpuinfo"

int get_cpu_frequency(double *frequency) {
    FILE *cpuinfo;
    char buf[1000];
    unsigned lineno;
    double freq;

    assert(frequency);

    cpuinfo = fopen(CPUINFO, "r");
    if (!cpuinfo) {
	fprintf(stderr, "Cannot open %s: %s\n", CPUINFO, strerror(errno));
	return -1;
    }

    lineno = 0;
    while (1) {
	++lineno;

	if (!fgets(buf, sizeof(buf), cpuinfo)) {
	    if (feof(cpuinfo))
		fprintf(stderr, "Reached EOF of %s "
			"before finding CPU frequency", CPUINFO);
	    else
		fprintf(stderr, "Cannot read from %s: %s", CPUINFO,
			strerror(errno));

	    return -1;
	}

	if (!strncmp(buf, "cpu MHz", 7)) {
	    const char *colon;
	    char *endptr;

	    /* find the colon */
	    colon = strchr(buf, ':');
	    if (!colon) {
		fprintf(stderr, "Found strange cpu frequency declaration at "
			"%s:%u, skipping", CPUINFO, lineno);
		continue;
	    }

	    freq = strtod(colon + 1, &endptr);
	    if ((*endptr != 0 && *endptr != '\n') || freq <= 0) {
		fprintf(stderr, "Invalid cpu frequency '%s' at %s:%u, "
			"skipping\n", colon + 1, CPUINFO, lineno);
		continue;
	    }

	    freq *= 1000000.;
	    break;
	}
    }

    fclose(cpuinfo);

    *frequency = freq;

    return 0;
}
