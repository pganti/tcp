#!/bin/bash -e
# $Id: makepatch.sh 3 2006-08-27 15:33:36Z aaron $ - vim:sw=4
#
# Creates a patch for tcpcallbacks from two kernel sources.
#
# Usage: makepatch.sh ORIG_KERNEL_DIR MODIFIED_KERNEL_DIR
#
# Author:	Aaron Isotton <aaron@isotton.com>

if [ -z "$1" -o -z "$2" ] ; then
    echo "Usage: $0 ORIG_KERNEL_DIR MODIFIED_KERNEL_DIR" >&2
    exit 1
fi

MODIFIED_FILES="net/ipv4/tcp_input.c net/ipv4/tcp_output.c include/linux/tcp.h"

PATCH=`mktemp`
for FILE in $MODIFIED_FILES ; do
    echo "Diffing $FILE" >&2
    diff -u "$1/$FILE" "$2/$FILE" >> $PATCH || true
done

cat $PATCH
rm -f $PATCH
